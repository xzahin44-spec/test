package com.example.bedrespawn;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class BedRespawnPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("BedRespawnPlugin activé !");
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Location bedLocation = player.getBedSpawnLocation();

        if (bedLocation != null) {
            Block block = bedLocation.getBlock();

            if (block.getType().toString().contains("BED")) {
                // Lit encore existant → Survival
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    player.setGameMode(GameMode.SURVIVAL);
                }, 1L);
                return;
            }
        }

        // Pas de lit → Spectator
        Bukkit.getScheduler().runTaskLater(this, () -> {
            player.setGameMode(GameMode.SPECTATOR);
        }, 1L);
    }
}