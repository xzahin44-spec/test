
package com.example.bedrespawn;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class BedRespawnPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("BedRespawnPlugin V2 activé !");
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Location loc = player.getRespawnLocation();

        boolean hasBed = false;

        if (loc != null) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    Material mat = loc.clone().add(x, 0, z).getBlock().getType();
                    if (mat.name().endsWith("_BED")) {
                        hasBed = true;
                        break;
                    }
                }
            }
        }

        GameMode withBed = GameMode.valueOf(getConfig().getString("mode.with-bed", "SURVIVAL"));
        GameMode withoutBed = GameMode.valueOf(getConfig().getString("mode.without-bed", "SPECTATOR"));

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (hasBed) {
                player.setGameMode(withBed);
            } else {
                player.setGameMode(withoutBed);
                player.sendMessage(getConfig().getString("message.eliminated", "Tu es éliminé !"));
            }
        }, 1L);
    }
}
